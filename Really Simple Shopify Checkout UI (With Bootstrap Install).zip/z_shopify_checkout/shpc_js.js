
jQuery(document).ready(function() {
	//Change Country, Postcode, State to 3 column
	jQuery('#billing_country_field, #billing_postcode_field, #billing_state_field, #shipping_country_field, #shipping_postcode_field, #shipping_state_field').addClass('d-inline-block col-lg-4 align-top');
	//Define the Class for the Multi Step
	var information_class = '.billing_title, #billing_form_step, #return_cart, #next_step, .woocommerce-account-fields';	
	var shiping_class = '.mts_email, .mts_address, .top_info_box, #shipping_method_step, #return_info, #payment_step';	
	var payment_class = '.mts_email, .mts_address, .mts_shipping, .top_info_box, .woocommerce-checkout-payment, #return_shipping, #confirm_order';
	
	
	//Defind the billing form validation
	var validate = 'false';
	function validate_checkout_field() {
		var email_checked = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var vstate = jQuery('#billing_state').val();
		var vpostcode = jQuery('#billing_postcode').val();
		var vcountry = jQuery('#billing_country').val();;
		var vfname = jQuery('#billing_first_name').val();
		var vlname = jQuery('#billing_last_name').val();
		var vemail = jQuery('#billing_email').val()
		var vadd1 = jQuery('#billing_address_1').val();
		var vcity = jQuery('#billing_city').val();
		var vusername = jQuery('#account_username').val();
		var vpassword = jQuery('#account_password').val();
		
		var email_valid = email_checked.test(vemail);
		
		if(vstate != '' && vpostcode != '' && vcountry != '' && vfname != '' && vlname != '' && vadd1 != '' && vcity != '' && email_valid != false ) {
		   
    		validate = 'true';
		    
			jQuery('#billing_email,#billing_postcode,#billing_first_name, #billing_last_name, #billing_city, #billing_address_1').next().remove();
			
			var email = jQuery('#billing_email').val();
			var company = jQuery('#billing_company').val();
			if(company == null || company == '') {
				company_line = '';
			} else {
				company_line = company + ', ';
			}
			var add1 = jQuery('#billing_address_1').val();
			var add2 = jQuery('#billing_address_2').val();
			if(add2 == null || add2 == '') {
				add2_line = '';
			} else {
				add2_line = add2 + ', ';
			}
			var city = jQuery('#billing_city').val();
			var state = jQuery('#select2-billing_state-container').attr('title');
			var postcode = jQuery('#billing_postcode').val();
			var country = jQuery('#select2-billing_country-container').attr('title');
			var fulladdress = company_line + add1 + ', ' + add2_line + city + ', ' + state + ', ' + postcode + ', ' + country;
			jQuery('#mts_address').html(fulladdress);
			jQuery('#mts_email').html(email);
			
		} else {
    		validate = 'false';
		   
			jQuery('#billing_email,#billing_postcode,#billing_first_name, #billing_last_name, #billing_city, #billing_address_1, #account_username, #account_password').next().remove();
			if(email_valid == false) {
				jQuery('#billing_email').parent().addClass('woocommerce-invalid');
				jQuery('#billing_email').next().remove();
				jQuery('#billing_email').parent().append('<small class="text-danger invalid_message">*Invalid Email Address.</small>');
			}
			if(vpostcode == '') {
				jQuery('#billing_postcode').parent().addClass('woocommerce-invalid');
				jQuery('#billing_postcode').next().remove();
				jQuery('#billing_postcode').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
			}
			if(vfname == '') {
				jQuery('#billing_first_name').parent().addClass('woocommerce-invalid');
				jQuery('#billing_first_name').next().remove();
				jQuery('#billing_first_name').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
			}
			if(vlname == '') {
				jQuery('#billing_last_name').parent().addClass('woocommerce-invalid');
				jQuery('#billing_last_name').next().remove();
				jQuery('#billing_last_name').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
			}
			if(vcity == '') {
				jQuery('#billing_city').parent().addClass('woocommerce-invalid');
				jQuery('#billing_city').next().remove();
				jQuery('#billing_city').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
			}
			if(vadd1 == '') {
				jQuery('#billing_address_1').parent().addClass('woocommerce-invalid');
				jQuery('#billing_address_1').next().remove();
				jQuery('#billing_address_1').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
			}
			
			if (jQuery('#createaccount').is(':checked')) {
    		    if(vusername != '' && vpassword != '' ) {
    		        jQuery('#account_username, #account_password').next().remove();
    		    } else {
    		        validate = 'false';
    		        if(vusername == '') {
        				jQuery('#account_username').parent().addClass('woocommerce-invalid');
        				jQuery('#account_username').next().remove();
        				jQuery('#account_username').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
        			}
        			if(vpassword == '') {
        				jQuery('#account_password').parent().addClass('woocommerce-invalid');
        				jQuery('#account_password').next().remove();
        				jQuery('#account_password').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
        			}
    		    }
		    }
		
		}
		
			
	}
	
	//Moving to Shipping Step
	jQuery('#next_step, .multistep-shipping').click(function() {
		validate_checkout_field();
		if(validate == 'true') {

			jQuery('.multistep-information, .multistep-payment').removeClass('multistep_active');
			jQuery('.multistep-shipping').addClass('multistep_active');
			
			jQuery('.woocommerce-shipping-fields').removeClass('active');
			jQuery(information_class + ',' + payment_class).hide();
			jQuery(shiping_class).fadeIn();
		}
		
	});
	
	//Moving to Payment Step
	jQuery('#payment_step, .multistep-payment').click(function() {
		validate_checkout_field();
		if(validate == 'true') {
			var shipping = jQuery('#shipping_method').find('.shipping_method:checked').next().text();
			jQuery('#mts_shipping').html(shipping);
			
			jQuery('.multistep-shipping, .multistep-information').removeClass('multistep_active');
			jQuery('.multistep-payment').addClass('multistep_active');
			
			jQuery(information_class + ',' + shiping_class).hide();
			jQuery(payment_class).fadeIn();
			
			jQuery('.woocommerce-shipping-fields').addClass('active');
		}
		
	});
	
	//Return to Information Step
	jQuery('#return_info, .information_change, .multistep-information').click(function() {
		validate_checkout_field();
		if(validate == 'true') {
			jQuery('.multistep-shipping, .multistep-payment').removeClass('multistep_active');
			jQuery('.multistep-information').addClass('multistep_active');
			
			jQuery('.woocommerce-shipping-fields').removeClass('active');
			jQuery(shiping_class + ',' + payment_class).hide();
			jQuery(information_class).fadeIn();
		}
		
	});
	
	//Return to Shipping Step
	jQuery('#return_shipping, .shipping_change').click(function() {
		validate_checkout_field();
		if(validate == 'true') {
			jQuery('.multistep-payment, .multistep-information').removeClass('multistep_active');
			jQuery('.multistep-shipping').addClass('multistep_active');
			
			jQuery('.woocommerce-shipping-fields').removeClass('active');
			jQuery(information_class + ',' + payment_class).hide();
			jQuery(shiping_class).fadeIn();
		}
	});
	
	
	//Check and Uncheck the checkbox for the Ship to Different Address
	jQuery("#ship-to-different-address-checkbox").prop( "checked", false );
	jQuery('#ship-to-different-address-checkbox').click(function(){
		jQuery('#same_as_billing').removeAttr('checked');
	});
	jQuery('#same_as_billing').click(function(){
		jQuery('#ship-to-different-address-checkbox').removeAttr('checked');
		jQuery('.shipping_address').slideUp();
	});
	
	//Confirm Order Button
	jQuery('#confirm_order').click(function(){
		//Define if the shipping to diffent address if checked, then validate the form
		var check_different_address = document.getElementById("ship-to-different-address-checkbox");
		if (check_different_address.checked == true){
			var sstate = jQuery('#shipping_state').val();
			var spostcode = jQuery('#shipping_postcode').val();
			var scountry = jQuery('#shipping_country').val();;
			var sfname = jQuery('#shipping_first_name').val();
			var slname = jQuery('#shipping_last_name').val();
			var sadd1 = jQuery('#shipping_address_1').val();
			var scity = jQuery('#shipping_city').val();
			
			if(sstate != '' && spostcode != '' && scountry != '' && sfname != '' && slname != '' && sadd1 != '' && scity != '') {
				jQuery('#shipping_postcode,#shipping_first_name,#shipping_last_name, #shipping_address_1, #shipping_city').next().remove();
				jQuery('#place_order').trigger('click');
			} else {
				jQuery('#shipping_postcode,#shipping_first_name,#shipping_last_name, #shipping_address_1, #shipping_city').next().remove();
				if(spostcode == '') {
					jQuery('#shipping_postcode').parent().addClass('woocommerce-invalid');
					jQuery('#shipping_postcode').next().remove();
					jQuery('#shipping_postcode').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
				}
				if(sfname == '') {
					jQuery('#shipping_first_name').parent().addClass('woocommerce-invalid');
					jQuery('#shipping_first_name').next().remove();
					jQuery('#shipping_first_name').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
				}
				if(slname == '') {
					jQuery('#shipping_last_name').parent().addClass('woocommerce-invalid');
					jQuery('#shipping_last_name').next().remove();
					jQuery('#shipping_last_name').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
				}
				if(scity == '') {
					jQuery('#shipping_city').parent().addClass('woocommerce-invalid');
					jQuery('#shipping_city').next().remove();
					jQuery('#shipping_city').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
				}
				if(sadd1 == '') {
					jQuery('#shipping_address_1').parent().addClass('woocommerce-invalid');
					jQuery('#shipping_address_1').next().remove();
					jQuery('#shipping_address_1').parent().append('<small class="text-danger invalid_message">*The field is required.</small>');
				}
			}
		} else {
			jQuery('#place_order').trigger('click');
		}
		
	});
	
	//Disable Checkout On Enter
	jQuery("form").keypress(function(e) {
	  //Enter key
	  if (e.which == 13) {
		return false;
	  }
	});
});