<?php 
 /*
Plugin Name: Fancy Owlsome
Plugin URI: https://www.fple.com
description: Owl Carousel 2.3.4, Fonts Awesome 5, Fancybox
Version: 1.0
Author: Fple Sdn Bhd
Author URI: https://www.fple.com
License: GPL2
*/


//Registered CSS & JS
function fpl_recent_file() {
	wp_register_style('fpl_owl', plugins_url('/assets/css/owl.carousel.min.css' ,__FILE__ ));
	wp_register_style('fpl_owl_thm', plugins_url('/assets/css/owl.theme.default.min.css' ,__FILE__ ));
	wp_register_style('fpl_fancy', plugins_url('/assets/css/jquery.fancybox.min.css' ,__FILE__ ));
	wp_enqueue_script('fpl_awesome', plugins_url('assets/js/fontawesome.js' ,__FILE__ ));
	
	wp_enqueue_style('fpl_owl');
	wp_enqueue_style('fpl_owl_thm');
	wp_enqueue_style('fpl_fancy');
}
add_action( 'wp_enqueue_scripts', 'fpl_recent_file' );

add_action( 'wp_footer', 'fpl_footer_script' );
function fpl_footer_script(){
  ?>
  <script src="<?php echo plugins_url('fancy_owlsome/assets/js/owl.carousel.min.js'); ?>"></script>
  <script src="<?php echo plugins_url('fancy_owlsome/assets/js/jquery.fancybox.min.js'); ?>"></script>
  <?php
}