<?php

function casino_list_display($atts) {
// Attributes
$atts = shortcode_atts(
array(
	'postid' => get_the_ID(),
), 
$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>


<?php if( have_rows('casino_list_post', $postid) ): ?>

	<div class="casinolist_display"> 
		<div class="casinolist_row">
			<?php
			$count = 1;
			while( have_rows('casino_list_post', $postid) ): the_row(); 
				$display_desc = get_sub_field('display_desc', $postid);
				$game_post = get_sub_field('choose_casino', $postid);
				$image_id = get_post_thumbnail_id($game_post);
				$website_url = get_sub_field('website_url', $postid);
			?>
			<div class="casinolist_item col">
				<div class="casinolist_bx row">
					<div class="col casinothumb">
					    <div class="casinolist_thumb">
					        <div class="num">
					            <span><?php echo $count; ?></span>
					        </div>
					        <img src="<?php echo wp_get_attachment_image_url($image_id, 'full'); ?>">
					    </div>
					    <div class="casinolist_title"><a href="<?php echo get_permalink($game_post); ?>"><?php echo get_the_title($game_post); ?></a></div>
					</div>
					<div class="col"><?php echo $display_desc; ?></div>
					<div class="col">
					    <div class="star-rating">

                            <?php $display_rating = get_sub_field('display_rating'); ?>
                            
                            <?php if ($display_rating == 'one'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star-value">1.0</div>
                            
                            <?php elseif ($display_rating == 'two'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star-value">2.0</div>
                            
                            <?php elseif ($display_rating == 'three'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-empty"></div>
                                <div class="star star-empty"></div>
                                <div class="star-value">3.0</div>
                            
                            <?php elseif ($display_rating == 'four'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-empty"></div>
                                <div class="star-value">4.0</div>
                            
                            <?php elseif ($display_rating == 'fourhalf'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-half"></div>
                                <div class="star-value">4.5</div>
                            
                            <?php elseif ($display_rating == 'five'): ?>
                            
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star star-full"></div>
                                <div class="star-value">5.0</div>
                            
                            <?php endif; ?>
                        
                        </div>

					    
					    <div><span>New players only</span></div>
					</div>
					<div class="col">
					    <div class="btn_group">
					        <a href="<?php echo $website_url;?>"><div class="btn_vst"><i class="fas fa-check-circle" aria-hidden="true"></i>VISIT</div></a>
					        <a href="<?php echo get_permalink($game_post); ?>"><div class="btn_rr"><i class="fas fa-arrow-alt-circle-right" aria-hidden="true"></i>Read Review</div></a>
					    </div>
					</div>
				</div>
				<div class="text-newplayer">
				    <p>18+. New players only. Welcome Bonus - Place 5 x €/$/£10 or more bets to receive €/$/£25 in free bets. This bonus only applies for deposits of €/$/£50 or higher! All you need to do is just deposit the money in your website.com account and you will receive this bonus instantly!</p>
				</div>
			</div>
		<?php $count++;endwhile; ?>			
		</div>	
	</div>

	<script> 
	</script>
<?php endif; ?>


<?php
return ob_get_clean();
}
add_shortcode('casino_list_display','casino_list_display');

