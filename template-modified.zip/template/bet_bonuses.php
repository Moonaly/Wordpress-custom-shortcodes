<?php

function bet_bonuses($atts) {
// Attributes
$atts = shortcode_atts(
array(
'postid' => get_the_ID(),
), 
$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<?php if( have_rows('bet_bonuses_row', $postid) ): ?>

	<div class="bet_bonuses_row row">
	    <div class="bet_bonuses_title">
            <h3>Texas bet Bonuses</h3>
        </div>
		<?php while( have_rows('bet_bonuses_row', $postid) ): the_row(); 
			$mini_title = get_sub_field('mini_title');
			$main_title = get_sub_field('main_title');
			$bonuscode = get_sub_field('bonuscode');
			$validity = get_sub_field('validity');
			$wht_blk_class = get_sub_field('wht_blk_class');
			$bonus_code = get_sub_field('bonus_code');
			//$display_title = get_sub_field('display_title', $postid);

		?>
		<div class="bet_bonuses_item col <?php echo $wht_blk_class; ?> <?php echo $bonus_code;?>">
			<div class="bet_bonuses_bx">
				<div class="bet_bonuses_first">
				    <span class="mini_title"><a href="#"><?php echo $mini_title; ?></a></span>
				    <h4 class="main_title"><?php echo $main_title; ?></h4>
				</div>
				<div class="bet_bonuses_second">
				    <span class="small-grey">Bonus Code</span>
				    <div class="bonuscode"><?php echo $bonuscode; ?></div>
				    <div class="validity">Valid Until:<span><?php echo $validity; ?></span></div>
				</div>
				<div class="bet_bonuses_third">
				    <span>100% match bonus</span><span>based on first deposit of £/$/€20+. Additional bonuses.</span>
				</div>
				<div class="bet_bonuses_fourth">
				    <a href="#">
				        <div class="btn_getbonus">Get Bonus</div>
				    </a>
				    <div><div class="tc_apply">T&Cs Apply</div></div>
				    <span>*New users only</span>
				</div>
			</div>
		</div>
	<?php endwhile; ?>			
	</div>	

<script> 
</script>
<?php endif; ?>

<?php
return ob_get_clean();
}
add_shortcode('bet_bonuses','bet_bonuses');

