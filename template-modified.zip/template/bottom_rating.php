<?php

function bottom_rating($atts) {
// Attributes
$atts = shortcode_atts(
array(
'postid' => get_the_ID(),
), 
$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<?php if (have_rows('bottom_rating', $postid)) : ?>
<div class="bottom_rating">
    <div class="br_row">
        <?php while (have_rows('bottom_rating', $postid)) : the_row();
           // $rating_title = get_sub_field('rating_title');
            $rating_list = get_sub_field('rating_list');
            $overall_rating = get_sub_field('overall_rating');
        ?>
            <div class="br_item col">
                    <div class="br_firstrow row">
                        <div class="col br_title">
                            <?//php echo $rating_title; ?>
                            <p class="small_grey">Get up to:</p>
                            <h3>100% Bonus</h3>
                            <strong>Up to first $500</strong>
                            <p class="small_grey">*New customers only.</p>
                        </div>
                        <div class="col btn_vst_link">
                            <div class="btn_vst_group">
                                <a href="#">
                                    <div class="btn_vst">
                                        VISIT<i class="fas fa-arrow-alt-circle-right" aria-hidden="true"></i>
                                    </div>
                                </a>
                                <p class="small_grey">New players only</p>
                            </div>
                        </div>
                    </div>   
                    <hr class="br_line">
                    <div class="br_secondrow row">
                        <?php if ($rating_list) : ?>
                            <div class="col br_tags_list">
                                <?php foreach ($rating_list as $tag) :
                                    $rating_number = $tag['rating_number'];
                                    $rating_list_inner = $tag['rating_list_inner'];
                                    if ($rating_number || $rating_list_inner) : ?>
                                        <div class="br_tag">
                                            <div class="br_tag_number">
												<?php if ($rating_number) : ?><?php echo $rating_number; ?> <?php endif; ?>
                                                <div class="star-icon">
    					                            <i class="fas fa-star" aria-hidden="true"></i>
    				                            </div>
                                            </div>
                                            <div class="br_tag_inner"><?php echo $rating_list_inner; ?></div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="col br_overall">
                            <div class="br_overall_bx">
                                <h3><?php echo $overall_rating; ?></h3>
                                <p>Overall Rating</p>
                            </div>
                        </div>
                    </div>  
                </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>


<?php
return ob_get_clean();
}
add_shortcode('bottom_rating','bottom_rating');

