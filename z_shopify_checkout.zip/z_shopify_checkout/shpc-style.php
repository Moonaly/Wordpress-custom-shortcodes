<?php
	$absolute_path = explode('wp-content', $_SERVER['SCRIPT_FILENAME']);
	$wp_load = $absolute_path[0] . 'wp-load.php';
	require_once($wp_load);

	/**
	Do stuff like connect to WP database and grab user set values
	*/
	header('Content-type: text/css');
	header('Cache-control: must-revalidate');
	$shpc_color = get_option('shpc_color');
	$shpc_btn_color = get_option('shpc_btn_color');
	$shpc_custom_css = get_option('shpc_custom_css');
	if($shpc_color) {
		$theme_color = $shpc_color;
		$theme_btn = $shpc_btn_color;
	} else {
		$theme_color = '#000';
		$theme_btn = '#fff';
	}

?>
.shpc_checkout a {
	color: <?php echo $theme_color; ?>;
}
.shpc_checkout a:hover {
	text-decoration: none;
	color: <?php echo $theme_color; ?>;
}
.shpc_logo {
	max-height: 32px;
    margin-bottom: 15px;
}
.breadcrumb_shpc {
    margin-bottom: 15px;
    border-bottom: dashed 1px <?php echo $theme_color; ?>;
}
.cart-step.breadcrumb_shpc ul li {
    text-transform: uppercase;
    font-size: 0.9rem;
	font-weight: 500;
	color: <?php echo $theme_color; ?>;
}
.cart-step.breadcrumb_shpc ul li a {
	color: <?php echo $theme_color; ?>;
}
.cart-step.breadcrumb_shpc ul li i {
    font-size: 0.8rem;
}
.cart-step.breadcrumb_shpc ul li.multistep_active {
	font-weight: bold;
}
.woocommerce form.shpc_checkout .form-row label {
    display: block;
    width: 100%;
    font-size: .9rem;
    margin-bottom: 0;
}
.shpc_checkout .woocommerce-input-wrapper {
	width: 100%;
}
.woocommerce form.shpc_checkout .form-row input:focus {
    outline: none;
    border: solid 1px <?php echo $theme_color; ?>;
    box-shadow: none;
}
#billing_form_step h3 {
    font-weight: 500;
    text-transform: uppercase;
    margin: 10px 0 0;
}
.woocommerce form.shpc_checkout .form-row#billing_email_field {
	margin-bottom: 0;
}
#billing_email_field:after {
    content: 'Billing Address';
    margin-top: 40px;
    display: inline-block;
    font-weight: 500;
    font-size: 18px;
    text-transform: uppercase;
}
#billing_address_2_field label, #shipping_address_2_field label {
	display: none;
}
.select2-container--default .select2-selection--single {
	height: 38px;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
	line-height: 38px;
}
#cart-submit-button-box {
	margin-top: 40px;
}
.btn.btn-themes, .btn.btn-themes:hover {
    background: <?php echo $theme_color; ?>;
    color: <?php echo $theme_btn;?>;
	cursor: pointer;
}
.btn.btn-themes:hover {
	opacity: 0.8;
}
.woocommerce .shpc_checkout .shop_table img {
    max-width: 60px;
}
.shpc_checkout strong.product-quantity {
    font-weight: 500;
    background: #eee;
    display: inline-block;
    width: 20px;
    height: 20px;
    font-size: .9rem;
    text-align: center;
    line-height: 20px;
    border-radius: 50%;
    position: absolute;
    top: -5px;
    right: -5px;
}
.shpc_checkout .coupon input#coupon_code {
	width: 100%;
	margin-right: 10px;
}
.shpc_checkout .coupon .shpc_apply_coupon {
	background: <?php echo $theme_color; ?>;
    color: <?php echo $theme_btn;?>;
    font-weight: 500;
    text-transform: uppercase;
    padding: 10px 30px;
}
.shpc_checkout .coupon .shpc_apply_coupon:hover {
	background: <?php echo $theme_color; ?>;
    color: <?php echo $theme_btn;?>;
	opacity: 0.8;
}
.shpc_checkout .coupon input:focus {
	outline: none;
}
.woocommerce .shpc_checkout  table.shop_table th:last-child, .woocommerce .shpc_checkout  table.shop_table td:last-child {
    text-align: right;
}
.woocommerce .shpc_checkout table.shop_table td, .woocommerce .shpc_checkout table.shop_table tbody th, .woocommerce .shpc_checkout table.shop_table tfoot td, .woocommerce .shpc_checkout table.shop_table tfoot th {
	font-weight: 500;
}
.shpc_checkout tr.order-total td span, .shpc_checkout tr.order-total th {
    font-size: 1.3rem;
    font-weight: 500;
}
#cartreturnlink {
    text-transform: uppercase;
    font-weight: 500;
}
#cartreturnlink i {
    font-size: .9rem;
}
.woocommerce-checkout-payment {
	display: none;
}
.top_info_box {
    border: solid 1px <?php echo $theme_color; ?>;
    border-radius: 5px;
	margin-top: 65px;
}
.info_box {
    border-top: solid 1px <?php echo $theme_color; ?>;
    align-items: center;
	padding: 5px 0;
}
.info_box:first-child {
	border-top: none;
}

.information_change, .shipping_change  {
	color: <?php echo $theme_color; ?>;
    font-weight: 500;
}
.woocommerce .shpc_checkout ul#shipping_method {
    border: solid 1px <?php echo $theme_color; ?>;
    padding: 5px 10px;
    border-radius: 5px;
    align-items: center;
}
.woocommerce .shpc_checkout ul#shipping_method li {
    margin: 10px 0;
    line-height: 1.5em;
    list-style: none outside;
    font-weight: 500;
}
.woocommerce .shpc_checkout ul#shipping_method .amount {
	font-weight: 500;
}
.woocommerce .shpc_checkout ul#shipping_method li input {
	margin-top: 6px;
}
 .woocommerce-checkout .shpc_checkout #payment {
	background: transparent;
}
.woocommerce-checkout .shpc_checkout #payment ul.payment_methods {
    border: solid 1px <?php echo $theme_color; ?>;
	border-bottom: none;
    border-radius: 5px;
	padding: 0;
}
.woocommerce-checkout #payment ul.payment_methods li .shpc_checkout_payment_method_wrapper {
    padding: 5px 10px;
    border-bottom: solid 1px <?php echo $theme_color; ?>;
}
.woocommerce-checkout .shpc_checkout #payment div.payment_box {
    margin: 0;
    background: #eee;
	border-bottom: solid 1px <?php echo $theme_color; ?>;
}
.woocommerce-checkout #payment div.payment_box::before {
	display: none;
	border-bottom: solid 1px <?php echo $theme_color; ?>;
}
.woocommerce-checkout .shpc_checkout #payment ul.payment_methods li input {
	margin-right: 5px;
}
.woocommerce-shipping-fields {
	opacity: 0;
	height: 0;
	visibility:hidden;
}
.woocommerce-shipping-fields.active {
	height: auto;
	opacity: 1;
	visibility: visible;
}
.multistep-information, .multistep-shipping, .multistep-payment, .information_change, .shipping_change, #return_shipping, #return_info   {
	cursor: pointer;
}
.multistep-information.multistep_active, .multistep-shipping.multistep_active, .multistep-payment.multistep_active {
	pointer-events: none;
}
.invalid_message {
	display:block;
}
@media screen and (min-width: 768px) {
	#ship-to-different-address .woocommerce-form__input-checkbox, .woocommerce-form__label-for-checkbox .woocommerce-form__input-checkbox.same_as_billing {
		position: unset;
		top:0;
		transform: unset;
		margin-right: 5px;
	}
}
@media screen and (max-width: 575px) {
	.top_info_box {
		margin-top: 30px;
	}
}

<?php 
echo $shpc_custom_css; ?>

