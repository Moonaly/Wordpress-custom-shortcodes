<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}

global $woocommerce;

$logo_url = get_option('logo_link');

?>


<form name="checkout" method="post" class="checkout woocommerce-checkout shpc_checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

	<div class="cart-step breadcrumb_shpc text-center">
		<?php if($logo_url) { ?><img src="<?php echo $logo_url; ?>" class="shpc_logo"><?php } ?>
		<ul class="d-block p-0 mx-auto text-center">
			<li class="d-inline-block"><a href="<?php echo wc_get_cart_url(); ?>">Cart</a></li>
			<li class="d-inline-block txtseparator"><i class="fas fa-chevron-right"></i></li>
			<li class="d-inline-block multistep-information multistep_active">Information</li>
			<li class="d-inline-block txtseparator"><i class="fas fa-chevron-right"></i></li>
			<li class="d-inline-block multistep-shipping">Shipping</li>
			<li class="d-inline-block txtseparator"><i class="fas fa-chevron-right"></i></li>
			<li class="d-inline-block multistep-payment">Payment</li>
		</ul>
	</div>

	<div class="row">
		<div class="col-sm-6">
			
			
			<div class="multistep_top_info mb-3">
				<div class="top_info_box container" style="display:none;">
					<div class="mts_email info_box row" style="display:none;">
						<div class="col-md-3 info_title inner_box">Contact: </div>
						<div class="col-md-7 info_details inner_box"><span id="mts_email"><?php echo $ck_user_meta['billing_email'][0]; ?></span></div> 
						<div class="col-md-2 info_change inner_box"><span class="information_change float-right">Change</span></div>
					</div>
					<div class="mts_address info_box row" style="display:none;">
						<div class="col-md-3 info_title inner_box">
							Address: 
						</div>
						<div class="col-md-7 info_details inner_box">
							<span id="mts_address"></span> 
						</div>
						<div class="col-md-2 info_change inner_box">
							<span class="information_change float-right">Change</span>
						</div>
					</div>
					<div class="mts_shipping info_box row" style="display:none;">
						<div class="col-md-3 info_title inner_box">
							Method: 
						</div> 
						<div class="col-md-7 info_details inner_box">
							<span id="mts_shipping"></span>
						</div>
						<div class="col-md-2 info_change inner_box">
							<span class="shipping_change float-right">Change</span>
						</div>
					</div>
				</div>
			</div>
		
			<?php if ( $checkout->get_checkout_fields() ) : ?>

				<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

				<div class="col2-set" id="customer_details">
					<div class="billing_address_step" id="billing_address_step">
						<?php do_action( 'woocommerce_checkout_billing' ); ?>
					</div>
					
					
					<div id="shipping_method_step" style="display:none;">
						<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>
							<?php wc_cart_totals_shipping_html_custom(); ?>
						<?php endif; ?>
					</div>

					<div class="shipping_address_step" id="shipping_address_step">
						<?php do_action( 'woocommerce_checkout_shipping' ); ?>
					</div>
				</div>

				<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>
				

			<?php endif; ?>
			
			<div id="cart-submit-button-box" class="row align-items-center">
				<div id="cartreturnlink" class="col-6">
					<a href="<?php echo wc_get_cart_url(); ?>" id="return_cart"><i class="fas fa-chevron-left"></i> Return to Cart</a>
					<span id="return_info" style="display:none;"><i class="fas fa-chevron-left"></i> Return to Information</span>
					<span id="return_shipping" style="display:none;"><i class="fas fa-chevron-left"></i> Return to Shipping</span>
				</div>
				<div id="cart-multi-button" class="col-6 text-right">
					<span id="confirm_order" style="display:none;" class="btn btn-themes">Confirm Order</span>
					<span id="next_step" class="btn btn-themes">Continue To Shipping</span>
					<span id="payment_step" style="display:none;" class="btn btn-themes">Continue To Payment</span>
				</div>
			</div>
		
		</div>
		<div class="col-sm-6">
		
			<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
	
			
			<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

			<div id="order_review" class="woocommerce-checkout-review-order">
				<h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3>
				<?php do_action( 'woocommerce_checkout_order_review' ); ?>
			</div>

			<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
				
		</div>
	</div>

	

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
