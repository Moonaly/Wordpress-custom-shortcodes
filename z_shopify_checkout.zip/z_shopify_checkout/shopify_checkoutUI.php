<?php 
 /*
Plugin Name: Really Simple Shopify Checkout UI
Plugin URI: https://www.fple.com
description: Monkeys also know used shopify checkout UI, need work together with bootstrap css.
Version: 1.5
Author: Fple Sdn Bhd
Author URI: https://www.fple.com
License: GPL2
*/


//Create Setting Menu
add_action('admin_menu', 'shopify_menu');
function shopify_menu() {

	//create new top-level menu
	add_menu_page('Shopify Checkout Setting', 'Shopify Checkout', 'administrator', __FILE__, 'shopify_settings_page' , plugins_url('/images/shpc_icon.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_shopify_checkout' );
}


function register_shopify_checkout() {
	//register our settings
	register_setting( 'shopify-settings-group', 'logo_link' );
	register_setting( 'shopify-settings-group', 'shpc_color' );
	register_setting( 'shopify-settings-group', 'shpc_btn_color' );
	register_setting( 'shopify-settings-group', 'shpc_custom_css' );
}

function shopify_settings_page() {
?>
<div class="wrap">
<h1>Shopify Checkout</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'shopify-settings-group' ); ?>
    <?php do_settings_sections( 'shopify-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Logo URL</th>
        <td><input type="text" name="logo_link" value="<?php echo esc_attr( get_option('logo_link') ); ?>" /></td>
        </tr>
        <tr valign="top">
        <th scope="row">Theme Color</th>
        <td><input type="text" name="shpc_color" value="<?php echo esc_attr( get_option('shpc_color') ); ?>" /></td>
        </tr>
		<tr valign="top">
        <th scope="row">Button Text Color</th>
        <td><input type="text" name="shpc_btn_color" value="<?php echo esc_attr( get_option('shpc_btn_color') ); ?>" /></td>
        </tr>
		<tr valign="top">
        <th scope="row">Custom CSS</th>
        <td><textarea id="shpc_custom_css" name="shpc_custom_css" rows="4" cols="50"><?php echo esc_attr( get_option('shpc_custom_css') ); ?></textarea></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php } 

//Add Styling
function shpc_scripts() {
	wp_register_style('shpc_scripts', plugins_url('shpc-style.php?v='.rand(1,999999) ,__FILE__ ));
	wp_register_style('shpc_scripts_bootstrap', plugins_url('bootstrap.min.css' ,__FILE__ ));
	wp_enqueue_script('checkout_script', plugins_url('shpc_js.js?v='.rand(1,999999) ,__FILE__ ));
	wp_enqueue_script('checkout_awesome_script', plugins_url('fontawesome.js' ,__FILE__ ));
	wp_enqueue_style('shpc_scripts');
	wp_enqueue_style('shpc_scripts_bootstrap');
}
add_action( 'wp_enqueue_scripts', 'shpc_scripts' );


/** Get the Woocommerce Plugin Files Path **/
function shpc_plugin_path() {
  // gets the absolute path to this plugin directory
	global $woocommerce, $wp, $post;
	
	return untrailingslashit( plugin_dir_path( __FILE__ ) );
	
}
add_filter( 'woocommerce_locate_template', 'shpc_woocommerce_locate', 10, 3 );


function shpc_woocommerce_locate( $template, $template_name, $template_path ) {
	global $woocommerce, $wp;

	$_template = $template;
	
	if ( ! $template_path ) $template_path = $woocommerce->template_url;
	$plugin_path  = shpc_plugin_path() . '/woocommerce/';

	// Modification: Get the template from this plugin, if it exists
	if ( file_exists( $plugin_path . $template_name ) ) {
		$template = $plugin_path . $template_name;
	} else {
		// Look within passed path within the theme - this is priority
		$template = locate_template(
		array(
				$template_path . $template_name,
				$template_name
			)
		);
	}

	// Use default template
	if ( ! $template )
	$template = $_template;

	// Return what we found
	return $template;
}

//Customize Shipping Method
function wc_cart_totals_shipping_html_custom() {
  $packages = WC()->shipping()->get_packages();
  $first    = true;

  foreach ( $packages as $i => $package ) {
    $chosen_method = isset( WC()->session->chosen_shipping_methods[ $i ] ) ? WC()->session->chosen_shipping_methods[ $i ] : '';
    $product_names = array();

    if ( count( $packages ) > 1 ) {
      foreach ( $package['contents'] as $item_id => $values ) {
        $product_names[ $item_id ] = $values['data']->get_name() . ' &times;' . $values['quantity'];
      }
      $product_names = apply_filters( 'woocommerce_shipping_package_details_array', $product_names, $package );
    }

    wc_get_template(
      'cart/cart-shipping.php',
      array(
        'package'                  => $package,
        'available_methods'        => $package['rates'],
        'show_package_details'     => count( $packages ) > 1,
        'show_shipping_calculator' => is_cart() && apply_filters( 'woocommerce_shipping_show_shipping_calculator', $first, $i, $package ),
        'package_details'          => implode( ', ', $product_names ),
        /* translators: %d: shipping package number */
        'package_name'             => apply_filters( 'woocommerce_shipping_package_name', ( ( $i + 1 ) > 1 ) ? sprintf( _x( 'Shipping %d', 'shipping packages', 'woocommerce' ), ( $i + 1 ) ) : _x( '<h4 class="text-uppercase">Shipping Method</h4>', 'shipping packages', 'woocommerce' ), $i, $package ),
        'index'                    => $i,
        'chosen_method'            => $chosen_method,
        'formatted_destination'    => WC()->countries->get_formatted_address( $package['destination'], ', ' ),
        'has_calculated_shipping'  => WC()->customer->has_calculated_shipping(),
      )
    );

    $first = false;
  }
}

add_filter( 'woocommerce_checkout_fields' , 'arrange_checkout_form' );
// Our hooked in function - $fields is passed via the filter!
function arrange_checkout_form( $fields ) {
    unset($fields['billing']['billing_phone']);
    unset($fields['shipping']['shipping_phone']);
    unset($fields['shipping']['shipping_address_2']['label']);
    unset($fields['order']['order_comments']);
	
	$fields['billing']['billing_email']['priority'] = 5;
	$fields['billing']['billing_company']['priority'] = 65;
	$fields['billing']['billing_country']['priority'] = 75;
	$fields['shipping']['shipping_company']['priority'] = 65;
	$fields['shipping']['shipping_country']['priority'] = 75;
	
    return $fields;
}
 
//Remove and Rename Default form field
add_filter( 'woocommerce_default_address_fields' , 'arrange_default_checkout_form' );
// Our hooked in function - $address_fields is passed via the filter!
function arrange_default_checkout_form( $address_fields ) {
     $address_fields['state']['priority'] = 85;
     $address_fields['city']['priority'] = 105;
     $address_fields['postcode']['priority'] = 95;

     return $address_fields;
}

//Hide Woocommerce notices
function hide_notice() {
	if(is_checkout()) {
		echo '<style>.woocommerce-notices-wrapper, .woocommerce-message, .woocommerce-error {
			display: none;
			visibility: hidden;
			opacity: 0;
		}</style>';
	}
}

add_action( 'woocommerce_after_checkout_billing_form', 'woocommerce_checkout_payment', 10 );
add_action( 'woocommerce_before_checkout_form', 'hide_notice', 2 );
remove_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 ); 

 