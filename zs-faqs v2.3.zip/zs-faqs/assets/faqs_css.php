<?php
	$absolute_path = explode('wp-content', $_SERVER['SCRIPT_FILENAME']);
	$wp_load = $absolute_path[0] . 'wp-load.php';
	require_once($wp_load);

	/**
	Do stuff like connect to WP database and grab user set values
	*/
	header('Content-type: text/css');
	header('Cache-control: must-revalidate');
	$type_color = get_option('faqs_type_color');
	$type_color_hover = get_option('faqs_type_hover');
	$type_background = get_option('faqs_typtbg');
	$type_background_hover = get_option('faqs_typbg_hover');
	$title_color = get_option('faqs_title_color');
	$title_color_hover = get_option('faqs_title_hover');
	$title_background = get_option('faqs_titbg');
	$title_background_hover = get_option('faqs_titbg_hover');
	$content_color = get_option('faqs_content_color');
	$content_background = get_option('faqs_conbg');
	if($type_color) { $type_color = $type_color; } else { $type_color = 'unset'; }
	if($type_color_hover) { $type_color_hover = $type_color_hover; } else { $type_color_hover = '#FFF'; }
	if($type_background) { $type_background = $type_background; } else { $type_background = 'unset'; }
	if($type_background_hover) { $type_background_hover = $type_background_hover; } else { $type_background_hover = '#216185'; }
	if($title_color) { $title_color = $title_color; } else { $title_color = '#212529'; }
	if($title_color_hover) { $title_color_hover = $title_color_hover; } else { $title_color_hover = '#FFF'; }
	if($title_background) { $title_background = $title_background; } else { $title_background = '#c8ceac'; }
	if($title_background_hover) { $title_background_hover = $title_background_hover; } else { $title_background_hover = '#216185'; }
	if($content_color) { $content_color = $content_color; } else { $content_color = '#212529'; }
	if($content_background) { $content_background = $content_background; } else { $content_background = 'rgb(200 206 172 / 30%)'; }

?>
.faqs_title-wrapper {
	cursor: pointer;
}
.faqs_title-wrapper.faqs_title-top {
    display: flex;
    justify-content: space-between;
}
.faqs_title-wrapper h4 {
    padding: 10px ;
    margin-bottom: 10px;
	border-radius: 5px;
}
.faqs_title-wrapper h4 {
	background: <?php echo $type_background; ?>;
	color: <?php echo $type_color; ?>;
	transition: all .3s ease;
}
.faqs_title-wrapper h4.active, .faqs_title-wrapper h4:hover {
	background: <?php echo $type_background_hover; ?>;
	color: <?php echo $type_color_hover; ?>;
	transition: all .3s ease;
}
.faqs-list-inner {
	display: none; 
}
.faqs-list-inner.faqs_type-0 {
	display: block;
}
.faqs_title-left .faqs_question:first-child {
	margin-top: 0;
}
.faqs_question {
    position: relative;
    display: inline-block;
    width: 100%;
    padding: 10px 40px 10px 20px;
    background: <?php echo $title_background; ?>;
    color: <?php echo $title_color; ?>;
	margin-top: 20px;
	border-radius: 5px;
	transition: all .3s ease;
}
.faqs_question h4 {
	margin-bottom: 0;
}
.faqs_question.active, .faqs_question:hover {
	background: <?php echo $title_background_hover; ?>;
    color: <?php echo $title_color_hover; ?>;
	transition: all .3s ease;
}
.faqs_answer {
	display: none;
	padding: 20px 15px;
	background: <?php echo $content_background; ?>;
	color: <?php echo $content_color; ?>;
	margin-top: -5px;
    border-radius: 0 0 15px 15px;
}
.faqs_question, .faqs_title-wrapper h4 {
	cursor: pointer;
}
.toggle_icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%) rotate(0);
	max-width:21px;
	max-height: 21px;
	transition: all .3s ease;
}
.faqs_question.active .toggle_icon{
	transform: translateY(-50%) rotate(180deg);
	transition: all .3s ease;
}
.toggle_icon img {
	vertical-align: top;
}
.faqs_question.active .icon_first {
	opacity: 0;
	transition: all .3s ease;
}
.icon_hover {
	position: absolute;
	top: 0;
	left: 0;
	opacity: 0;
	top: 50%;
    transform: translateY(-50%);
	transition: all .3s ease;
}
.faqs_question.active .icon_hover, .icon_first  {
	opacity: 1;
	transition: all .3s ease;
}

@media screen and (max-width: 767px) {
	.faqs_title-wrapper.faqs_title-top {
		white-space: nowrap;
		overflow-x: auto;
	}
	.faqs_title-wrapper {
		display: inline-flex;
		overflow-x: auto;
		white-space: nowrap;
		width: 100%;
	}
	.faqs_title-wrapper h4 {
		margin-right: 1rem;
	}
	.faqs_title-wrapper h4:last-child {
		margin-right: 0;
	}
	.faqs_title-left .faqs_question:first-child {
		margin-top: 20px;
	}
}