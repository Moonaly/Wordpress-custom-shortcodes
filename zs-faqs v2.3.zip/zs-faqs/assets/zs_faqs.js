jQuery(document).ready(function(){
	jQuery('.zs_faqs-wrapper').find('.faqs_question').click(function(){
		jQuery(this).toggleClass('active').next().slideToggle();
		jQuery('.zs_faqs-wrapper .faqs_question').not(jQuery(this)).removeClass('active').next().slideUp();
	});
	jQuery('.faqs_title-wrapper').find('h4').click(function(){
		var faqs_title = jQuery(this).attr('data-faqs');
		jQuery(this).addClass("active");
		jQuery(".faqs_title-wrapper").find("h4").not(jQuery(this)).removeClass("active");
		jQuery('.faqs-list-inner.faqs_type-'+faqs_title).fadeIn();
		jQuery('.faqs-list-inner').not(jQuery('.faqs_type-'+faqs_title)).hide();
	});
});