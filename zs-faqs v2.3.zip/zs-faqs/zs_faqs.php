<?php
/*
Plugin Name: 	ZS FAQs
Description: 	ZS FAQs Plugin
Version: 		1.0.0
Author: 		ZS Team
Text Domain: 	zs-services
Domain Path:	/languages
License: 		GPLv2 or later
License URI:	http://www.gnu.org/licenses/gpl-2.0.html

*/

if ( !is_admin() ) {
	include_once('faqs_shortcode.php');
}
if( is_admin() ) {
	include_once('faqs_admin.php');

}

