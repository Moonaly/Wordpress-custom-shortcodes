<?php
//Create Setting Menu
add_action('admin_menu', 'zs_faqs_menu');
function zs_faqs_menu() {

	//create new top-level menu
	add_menu_page('ZS FAQs', 'ZS FAQ', 'administrator', __FILE__, 'zs_faqs_setting' , plugins_url('img/faq.png?v=2.1', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_zs_faq' );
}

function register_zs_faq() {
	//register our settings
	register_setting( 'zs-settings-faqs', 'faqs_type_color' );
	register_setting( 'zs-settings-faqs', 'faqs_type_hover' );
	register_setting( 'zs-settings-faqs', 'faqs_typtbg' );
	register_setting( 'zs-settings-faqs', 'faqs_typbg_hover' );
	register_setting( 'zs-settings-faqs', 'faqs_title_color' );
	register_setting( 'zs-settings-faqs', 'faqs_title_hover' );
	register_setting( 'zs-settings-faqs', 'faqs_titbg' );
	register_setting( 'zs-settings-faqs', 'faqs_titbg_hover' );
	register_setting( 'zs-settings-faqs', 'faqs_content_color' );
	register_setting( 'zs-settings-faqs', 'faqs_conbg' );
	register_setting( 'zs-settings-faqs', 'faqs_plus' );
	register_setting( 'zs-settings-faqs', 'faqs_minus' );
}

function zs_faqs_setting() {
?>
<div class="wrap">
<h1>ZS FAQs</h1>
<p><strong>Shortcode: </strong>[zs_faqs]</p>
<p><strong>Instruction:</strong><br>Download and import the data to Advanced Custom Field from the link below<br><a href="<?php echo  plugins_url('zs-faqs/import/zs_faqs_acf_import.json'); ?>" download><?php echo  plugins_url('zs-faqs/import/zs_faqs_acf_import.json'); ?></a><br><strong><em>To import the ACF fields, go to Custom Fields > Tools > Import Field Group</em></strong></p>
<form method="post" action="options.php">
    <?php settings_fields( 'zs-settings-faqs' ); ?>
    <?php do_settings_sections( 'zs-settings-faqs' ); ?>
    <table class="form-table">
		<tr valign="top">
			<th scope="row">Type Color</th>
			<td width="30%"><input type="text" name="faqs_type_color" value="<?php echo esc_attr( get_option('faqs_type_color') ); ?>" /></td>
			<td rowspan="2"><img src="<?php echo plugins_url('img/sh01.png', __FILE__); ?>" style="max-width: 180px;"></td> 
        </tr>
		<tr valign="top">
			<th scope="row">Type Color Hover</th>
			<td><input type="text" name="faqs_type_hover" value="<?php echo esc_attr( get_option('faqs_type_hover') ); ?>" /></td>
        </tr>
        <tr valign="top">
			<th scope="row">Type Background</th>
			<td><input type="text" name="faqs_typtbg" value="<?php echo esc_attr( get_option('faqs_typtbg') ); ?>" /></td>
			<td rowspan="2"><img src="<?php echo plugins_url('img/sh02.png', __FILE__); ?>" style="max-width: 180px;"></td> 
        </tr>
        <tr valign="top">
			<th scope="row">Type Background (Hover)</th>
			<td><input type="text" name="faqs_typbg_hover" value="<?php echo esc_attr( get_option('faqs_typbg_hover') ); ?>" /></td>
        </tr>
		<tr valign="top">
			<th scope="row">Title Color</th>
			<td><input type="text" name="faqs_title_color" value="<?php echo esc_attr( get_option('faqs_title_color') ); ?>" /></td>
			<td rowspan="2"><img src="<?php echo plugins_url('img/sh03.png', __FILE__); ?>" style="max-width: 180px;"></td> 
        </tr>
		<tr valign="top">
			<th scope="row">Title Color Hover</th>
			<td><input type="text" name="faqs_title_hover" value="<?php echo esc_attr( get_option('faqs_title_hover') ); ?>" /></td>
        </tr>
        <tr valign="top">
			<th scope="row">Title Background</th>
			<td><input type="text" name="faqs_titbg" value="<?php echo esc_attr( get_option('faqs_titbg') ); ?>" /></td>
			<td rowspan="2"><img src="<?php echo plugins_url('img/sh04.png', __FILE__); ?>" style="max-width: 180px;"></td> 
        </tr>
        <tr valign="top">
			<th scope="row">Title Background (Hover)</th>
			<td><input type="text" name="faqs_titbg_hover" value="<?php echo esc_attr( get_option('faqs_titbg_hover') ); ?>" /></td>
        </tr>
		<tr valign="top">
			<th scope="row">Content Color</th>
			<td><input type="text" name="faqs_content_color" value="<?php echo esc_attr( get_option('faqs_content_color') ); ?>" /></td>
			<td rowspan="2"><img src="<?php echo plugins_url('img/sh05.png', __FILE__); ?>" style="max-width: 180px;"></td>
        </tr>
		<tr valign="top">
			<th scope="row">Content Background</th>
			<td><input type="text" name="faqs_conbg" value="<?php echo esc_attr( get_option('faqs_conbg') ); ?>" /></td>
        </tr>
		<tr valign="top">
			<th scope="row">Plus Icon Url</th>
			<td><input type="text" name="faqs_plus" size="60" value="<?php echo get_option('faqs_plus'); ?>"></td>
        </tr>
		<tr valign="top">
			<th scope="row">Minus Icon Url</th>
			<td><input type="text" name="faqs_minus" size="60" value="<?php echo get_option('faqs_minus'); ?>"></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>
</form>

</div>
<?php } 
