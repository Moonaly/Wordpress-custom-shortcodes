<?php 
function faqs_scripts() {
	wp_enqueue_style( 'zs-faqs-style', plugins_url('/assets/faqs_css.php?v='.rand(1,9999999), __FILE__ ) );
	wp_enqueue_script( 'zs-faqs-script', plugins_url('/assets/zs_faqs.js?v='.rand(1,99999999), __FILE__) , array(), '', true );
}
add_action( 'wp_enqueue_scripts', 'faqs_scripts' );

//FAQs Shortcode
function zs_faqs($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'postid' => get_the_ID(),
		), 
		$atts
	);
	// Attributes in var
	$post_id = $atts['postid'];
	$faqs_type = get_field('faqs_type', $post_id);
	$faqs_column = get_field('faqs_column', $post_id);
	$title_position = get_field('title_position', $post_id);
	$faqs_with_title = get_field('faqs_with_title', $post_id);
	$faqs_without_title = get_field('faqs_without_title', $post_id);
	$plus_url = get_option('faqs_plus');
	$minus_url = get_option('faqs_minus');
	if(!$plus_url) { $plus_url = plugins_url('img/plus.svg', __FILE__); }
	if(!$minus_url) { $minus_url = plugins_url('img/minus.svg', __FILE__); }
	$toggle_icon = '<div class="toggle_icon"><img src="'.$plus_url.'" class="icon_first"><img src="'.$minus_url.'" class="icon_hover"></div>';
	
	if($faqs_column == 'two') { $col_class = 'col-lg-6'; } else { $col_class = 'col-12'; }
	
	$output ='<div class="zs_faqs-wrapper">';
	$output.='<div class="faqs-list">';
	if($faqs_type == 'with' && $title_position == 'left'):
		$faqs_left = 0;
		$faqs_left_2 = 0;
		
		$output.='<div class="row">';
		$output.='<div class="col-lg-3">';
		$output.='<div class="faqs_title-wrapper">';  
		foreach($faqs_with_title as $fwt): 
			if($faqs_left == 0) {
				$output.='<h4 data-faqs="'.$faqs_left.'" class="active">'.$fwt['question_title'].'</h4>';
			} else {
				$output.='<h4 data-faqs="'.$faqs_left.'">'.$fwt['question_title'].'</h4>';
			}
			
		$faqs_left++;endforeach;
		$output.='</div>'; //faqs_title-wrapper
		$output.='</div>'; //col-lg-4
		$output.='<div class="col-lg-9">';
		$output.='<div class="faqs_title-left">';
			foreach($faqs_with_title as $fwt): 
			$fwt_list = $fwt['question_list'];
			$output.='<div class="faqs-list-inner faqs_type-'.$faqs_left_2.'">';
				foreach($fwt_list as $list):
					$output.='<div class="faqs_list">';
					$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
					$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
					$output.='</div>';//faqs_list
				endforeach;
			$output.='</div>';
			$faqs_left_2++;endforeach;
		$output.='</div>';//faqs_title-left
		$output.='</div>';
		$output.='</div>';//row
	else: 
		if($faqs_type == 'with'):
			$faqs_top = 0; $faqs_title = 0;
			
			$output.='<div class="faqs_title-wrapper faqs_title-top">';
			foreach($faqs_with_title as $fwt): 
				if($faqs_title == 0) {
					$output.='<h4 data-faqs="'.$faqs_title.'" class="active">'.$fwt['question_title'].'</h4>';
				} else {
					$output.='<h4 data-faqs="'.$faqs_title.'">'.$fwt['question_title'].'</h4>';
				}
				$faqs_title++;endforeach;
				$output.='</div>'; //faqs_title-wrapper
			
			foreach($faqs_with_title as $fwt): 
				$fwt_list = $fwt['question_list'];
				
				$output.='<div class="faqs-list-inner faqs_type-'.$faqs_top.'">';
				$output.='<div class="row">';
				if($faqs_column == 'two'):
					$faqsLength = count($fwt_list);
					$faqsLength_half = round($faqsLength / 2);
					$left_list = array_slice($fwt_list, 0, $faqsLength_half);
					$right_list = array_slice($fwt_list, $faqsLength_half, $faqsLength);
					
					$output.='<div class="'.$col_class.'">';
					foreach($left_list as $list):
						$output.='<div class="faqs_list">';
						$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
						$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
						$output.='</div>';//faqs_list
					endforeach;
					$output.='</div>';
					
					$output.='<div class="'.$col_class.'">';
					foreach($right_list as $list):
						$output.='<div class="faqs_list">';
						$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
						$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
						$output.='</div>';//faqs_list
					endforeach;
					$output.='</div>';
				else:
					foreach($fwt_list as $list):
						$output.='<div class="'.$col_class.'">';
						$output.='<div class="faqs_list">';
						$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
						$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
						$output.='</div>';//faqs_list
						$output.='</div>';
					endforeach;
				endif;
				$output.='</div>';//row
				$output.='</div>'; //faqs-list-inner
			$faqs_top++;endforeach;
		else:
			//$faqs_count = 0;
			$output.='<div class="row">';
			if($faqs_column == 'two'):
				$faqsLength = count($faqs_without_title);
				$faqsLength_half = round($faqsLength / 2);
				$left_list = array_slice($faqs_without_title, 0, $faqsLength_half);
				$right_list = array_slice($faqs_without_title, $faqsLength_half, $faqsLength);
	
				$output.='<div class="'.$col_class.'">';
				foreach($left_list as $list):
					$output.='<div class="faqs_list">';
					$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
					$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
					$output.='</div>';//faqs_list
				endforeach;
				$output.='</div>';
				
				$output.='<div class="'.$col_class.'">';
				foreach($right_list as $list):
					$output.='<div class="faqs_list">';
					$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
					$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
					$output.='</div>';//faqs_list
				endforeach;
				$output.='</div>';
			else:
				$output.='<div class="'.$col_class.'">';
				foreach($faqs_without_title as $list):
					$output.='<div class="faqs_list">';
					$output.='<div class="faqs_question"><h4>'.$list['title'].'</h4>'.$toggle_icon.'</div>';
					$output.='<div class="faqs_answer">'.$list['answer'].'</div>';
					$output.='</div>';//faqs_list
				endforeach;
				$output.='</div>';
			endif;
			$output.='</div>';//row
		endif;
	endif;
	$output.='</div>'; //faqs-list
	$output.='</div>';
		

	return $output;
		}
add_shortcode('zs_faqs','zs_faqs');