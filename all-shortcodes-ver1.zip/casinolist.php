<?php

function casino_list($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<?php
$featured_posts = get_field('casino_list');
if( $featured_posts ): ?>
<div class="postslisting">
<div class="postlisting_bx row">
<?php foreach( $featured_posts as $post ): 

    // Setup this post for WP functions (variable must be named $post).
    setup_postdata($post); ?>
    <div class="col">

        <div class="postscard">
            <div class="poststhumb">
              <?php if(get_the_post_thumbnail($post)) {
                // Get the URL of the post
                $post_url = get_permalink($post);
                // Wrap the thumbnail image in an anchor tag that links to the post
                echo '<a href="' . $post_url . '">' . get_the_post_thumbnail($post) . '</a>';
              } ?>
            </div>
    		<div class="postsinfo">
                <h4><a href="<?php echo get_the_permalink($post); ?>"><?php echo get_the_title($post); ?></a></h4>
                <div class="timestamp">
    		        <span><i class="far fa-clock" aria-hidden="true"></i></span><p><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></p>
    		    </div>
            </div>
        </div>

    </div>
<?php endforeach; ?>
</div>
</div>    
<?php 
// Reset the global post object so that the rest of the page works correctly.
wp_reset_postdata(); ?>
<?php endif; ?>


<?php
return ob_get_clean();
}
add_shortcode('casino_list','casino_list');

