<?php 

function betdetails($atts) {
// Attributes
$atts = shortcode_atts(
array(
'postid' => get_the_ID(),
), 
$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>


<?php if( have_rows('bet_details', $postid) ): ?>
<div class="bet_details"> 
    <div class="betdetails_row">
        <?php while( have_rows('bet_details', $postid) ): the_row();
            $betdetails_icon = get_sub_field('betdetails_icon');
            $betdetails_title = get_sub_field('betdetails_title');
            $betdetails_tags = get_sub_field('betdetails_tags');
            $betdetails_tags_list = $betdetails_tags['betdetails_tags_list']; // this line is not needed anymore
        ?>
            <div class="betdetails_item col">
                <div class="betdetails_bx row">
                    <div class="betdetails_title col-md-3">
                        <div class="betdetails_icons">
                            <img src="<?php echo $betdetails_icon;?>">
                        </div>
                        <?php echo $betdetails_title;?>
                    </div>
                    <?php if( $betdetails_tags ): ?>
                        <div class="betdetails_tags_list col-md-9">
                            <?php foreach( $betdetails_tags as $tag ): ?>
                                <?php if( $tag['betdetails_tags_list'] ): ?>
                                    <span href="#"><?php echo $tag['betdetails_tags_list']; ?></span>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>    
</div>
<?php endif;  ?>











<?php
return ob_get_clean();
}
add_shortcode('betdetails','betdetails');

