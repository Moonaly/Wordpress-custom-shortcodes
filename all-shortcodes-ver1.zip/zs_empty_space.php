<?php 
function create_zsemptyspace_shortcode($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'desktop' => '60px',
			'table_pro' => '60px',
			'tablet' => '40px',
			'mobile' => '40px',
		),
		$atts,
		'ch_empty_space'
	);
	// Attributes in var
	$desktop = str_replace('px','',$atts['desktop']);
	$table_pro = str_replace('px','',$atts['table_pro']);
	$tablet = str_replace('px','',$atts['tablet']);
	$mobile = str_replace('px','',$atts['mobile']);


	// Output Code
	$output='<div class="zs_empty_space" data-desktop="'.$desktop.'" data-table_pro="'.$table_pro.'" data-tablet="'.$tablet.'" data-mobile="'.$mobile.'"></div>';

	return $output;
}
add_shortcode( 'zs_empty_space', 'create_zsemptyspace_shortcode' );