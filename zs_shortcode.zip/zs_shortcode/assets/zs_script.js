jQuery(document).ready(function(){
	var w = jQuery(window).width();
	jQuery(".zs_empty_space").each(function(){
		if( w > 767 && w < 992){
			h = jQuery(this).attr("data-table_pro");
		} else if( w > 576 && w < 768) {
			h = jQuery(this).attr("data-tablet");
		} else if( w < 577 ) {
			h = jQuery(this).attr("data-mobile");
		} else {
			h = jQuery(this).attr("data-desktop");
		}
		jQuery(this).attr("style", "height:"+h+"px");
	});
});