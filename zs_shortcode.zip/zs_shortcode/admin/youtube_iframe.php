<?php
// Create YouTube Iframe element for Visual Composer
add_action( 'vc_before_init', 'youtubeiframe_integrateWithVC' );
function youtubeiframe_integrateWithVC() {
	vc_map( array(
		'name' => __( 'YouTube Iframe', 'textdomain' ),
		'base' => 'youtube_iframe',
		'show_settings_on_create' => true,
		'category' => __( 'Content', 'textdomain'),
		'icon' => 'zs_icon',
		'params' => array(
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Youtube ID', 'textdomain' ),
				'param_name' => 'youtube_id',
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Iframe Width', 'textdomain' ),
				'param_name' => 'iframe_width',
				'value' => '100%',
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Iframe Height', 'textdomain' ),
				'param_name' => 'iframe_height',
				'value' => '400',
				'description' => __( 'No need px', 'textdomain' )
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Title', 'textdomain' ),
				'param_name' => 'title',
			),
			array(
				'type' => 'checkbox',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Controls', 'textdomain' ),
				'param_name' => 'controls',
			),
			array(
				'type' => 'checkbox',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Autoplay', 'textdomain' ),
				'param_name' => 'autoplay',
			),
			array(
				'type' => 'checkbox',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Mute', 'textdomain' ),
				'param_name' => 'mute',
			),
			array(
				'type' => 'checkbox',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Loop', 'textdomain' ),
				'param_name' => 'loop',
			),
			array(
				'type' => 'checkbox',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Pointer Events None', 'textdomain' ),
				'param_name' => 'pointer',
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Wrapper Class', 'textdomain' ),
				'param_name' => 'wrapper_class',
			),
		)
	) );
}