<?php 
// Create ZS Empty Space element for Visual Composer
add_action( 'vc_before_init', 'chemptyspace_integrateWithVC' );
function chemptyspace_integrateWithVC() {
	vc_map( array(
		'name' => __( 'ZS Empty Space', 'textdomain' ),
		'base' => 'zs_empty_space',
		'show_settings_on_create' => true,
		'category' => __( 'Content', 'textdomain'),
		'icon' => 'zs_icon',
		'params' => array(
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Deskstop', 'textdomain' ),
				'param_name' => 'desktop',
				'value' => '60px',
				'description' => __( '992px Above', 'textdomain' )
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Tablet Pro', 'textdomain' ),
				'param_name' => 'table_pro',
				'value' => '60px',
				'description' => __( '768px &  991px', 'textdomain' )
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Tablet', 'textdomain' ),
				'param_name' => 'tablet',
				'value' => '40px',
				'description' => __( '577px & 767px', 'textdomain' )
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'class' => '',
				'admin_label' => true,
				'heading' => __( 'Mobile', 'textdomain' ),
				'param_name' => 'mobile',
				'value' => '40px',
				'description' => __( '576px Below', 'textdomain' )
			),
		)
	) );
}