<?php
function template($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'postid' => get_the_ID(),
		), 
		$atts
	);
	// Attributes in var
	$post_id = $atts['postid'];
	
	$output .= 'Hello World';
	
	return $output;
		}
add_shortcode('template','template');

function template_html($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'postid' => get_the_ID(),
		), 
		$atts
	);
	// Attributes in var
	$post_id = $atts['postid']; 
	ob_start();
	?>
	
	<div class="template_html">
		Hello World
	</div>
	
	<?php
	return ob_get_clean();
		}
add_shortcode('template_html','template_html');
