<?php
function template($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid'];

$output .= 'Hello World';

return $output;
}
add_shortcode('template','template');

function template_html($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<div class="template_html">
Hello World
</div>

<?php
return ob_get_clean();
}
add_shortcode('template_html','template_html');



function btn_green($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<a href="#">
<div class="btn_green">
	Get Bonus
</div>
</a>

<?php
return ob_get_clean();
}
add_shortcode('btn_green','btn_green');


function top_breadcrumbs($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>
<div class="top_breadcrumbs">
<div class=" container">
	<h1 class="breadcrumbs-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
	<p class="breadcrumbs-substitle"><span><a href="<?php echo get_site_url(); ?>">Home</a></span><span> » </span><span><?php the_title(); ?></span></p>
</div>
</div>

<?php
return ob_get_clean();
}
add_shortcode('top_breadcrumbs','top_breadcrumbs');

function posts_quote($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>
<blockquote class="block-quote">
<div class="icon-quote">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M0 216C0 149.7 53.7 96 120 96h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V320 288 216zm256 0c0-66.3 53.7-120 120-120h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64H320c-35.3 0-64-28.7-64-64V320 288 216z"/></svg>
</div>
<p><?php echo  get_field( 'post_quote' ); ?></p>
<cite><?php echo  get_field( 'post_quote_citer' ); ?></cite>
</blockquote>

<?php
return ob_get_clean();
}
add_shortcode('posts_quote','posts_quote');

function pros_cons($atts) {
// Attributes
$atts = shortcode_atts(
	array(
		'postid' => get_the_ID(),
	), 
	$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<div class="pros_cons_container"> 
<div class="pros_cons_row row">
    <div class="col pros_contain">
        <div class="pros_inner">
            <div class="icon_cir_plus">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM232 344V280H168c-13.3 0-24-10.7-24-24s10.7-24 24-24h64V168c0-13.3 10.7-24 24-24s24 10.7 24 24v64h64c13.3 0 24 10.7 24 24s-10.7 24-24 24H280v64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"/></svg>
            </div>
            <h4>Pros</h4>
            <?php if( have_rows('pros', $postid) ): ?>
            			<?php while( have_rows('pros', $postid) ): the_row(); 
            				$pros_content = get_sub_field('pros_content');
            				//$display_title = get_sub_field('display_title', $postid);
            			?>
            			<div class="pros_item">
                            <p>
                                <span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg></span>
                                <?php echo $pros_content;?>
                            </p>
            			</div>
            		<?php endwhile; ?>			
            
            	<script> 
            	</script>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="col cons_contain">
        <div class="cons_inner">
            <div class="icon_cir_minus">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM184 232H328c13.3 0 24 10.7 24 24s-10.7 24-24 24H184c-13.3 0-24-10.7-24-24s10.7-24 24-24z"/></svg>
            </div>
            <h4>Cons</h4>
            <?php if( have_rows('cons', $postid) ): ?>
            			<?php while( have_rows('cons', $postid) ): the_row(); 
            				$cons_content = get_sub_field('cons_content');
            				//$display_title = get_sub_field('display_title', $postid);
            			?>
            			<div class="cons_item">
                            
                            <p>
                                <span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z"/></svg></span>
                                <?php echo $cons_content;?>
                            </p>
            			</div>
            		<?php endwhile; ?>			
            
            	<script> 
            	</script>
            <?php endif; ?>
        </div>
    </div>
</div>
</div> 

<?php
return ob_get_clean();
}
add_shortcode('pros_cons','pros_cons');
