<?php

function footer_display_posts($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'postid' => get_the_ID(),
		), 
		$atts
	);
	// Attributes in var
	$post_id = $atts['postid']; 
	ob_start();
?>
<div class="container footerlatest_title">
	<h4>Top Rated Bookmakers</h4>
</div>
<div id="footerlatest-post" class="container">
	<?php
	$recent_posts = wp_get_recent_posts(array(
		'post_type'   => 'casino_list',
		'numberposts' => 8, // Number of recent posts thumbnails to display
		'post_status' => 'publish' // Show only the published posts
	));
	$count = 0;
	?>
	<div class="row">
		<?php foreach( $recent_posts as $post_item ) : ?>
		<div class="footerpost-items col-md-3">
			<a href="<?php echo get_permalink($post_item['ID']) ?>">
				<div class="img"><?php echo get_the_post_thumbnail($post_item['ID'], 'full'); ?></div>
				<div class="info">
					<div class="title"><h4 class="slider-caption-class"><?php echo $post_item['post_title'] ?></h4></div>
					<div class="ft-star-rating">

							<?php $display_rating = get_field('display_rating',$post_item['ID'] ); ?>
							<?php if ($display_rating == 'one'): ?>

							<div class="star star-full"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>

							<?php elseif ($display_rating == 'two'): ?>

							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>

							<?php elseif ($display_rating == 'three'): ?>

							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-empty"></div>
							<div class="star star-empty"></div>

							<?php elseif ($display_rating == 'four'): ?>

							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-empty"></div>

							<?php elseif ($display_rating == 'fourhalf'): ?>

							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-half"></div>

							<?php elseif ($display_rating == 'five'): ?>

							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>
							<div class="star star-full"></div>

							<?php endif; ?>

					
					</div>
					<div class="content">
						<?php
	$post_content = $post_item['post_content']; // get the post content
	$post_content = preg_replace('/\[.*?\]/', '', $post_content); // remove any square bracket tags
	$post_content = strip_tags($post_content); // remove any remaining HTML tags
	$trimmed_content = wp_trim_words($post_content, 12, '...'); // trim the text
	echo $trimmed_content; // display the trimmed text
						?>

					</div>
				</div>
			</a>
		</div>
		<?php
	$count++;
	if ($count % 4 == 0) {
		echo '</div><div class="row">';
	}
		?>
		<?php endforeach; ?>
	</div>

</div>

<?php
	return ob_get_clean();
}
add_shortcode('footer_display_posts','footer_display_posts');

