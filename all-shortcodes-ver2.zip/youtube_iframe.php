<?php
function create_youtubeiframe_shortcode($atts) {
	// Attributes
	$atts = shortcode_atts(
		array(
			'youtube_id' => '',
			'iframe_width' => '100%',
			'iframe_height' => '400',
			'title' => '',
			'controls' => '',
			'autoplay' => '',
			'mute' => '',
			'loop' => '',
			'pointer' => '',
			'wrapper_class' => '',
		),
		$atts,
		'youtube_iframe'
	);
	// Attributes in var
	$youtube_id = $atts['youtube_id'];
	$iframe_width = $atts['iframe_width'];
	$iframe_height = $atts['iframe_height'];
	$title = $atts['title'];
	$pointer = $atts['pointer'];
	$wrapper_class = $atts['wrapper_class'];
	$controls = $atts['controls'] ? 1 : 0;
	$autoplay = $atts['autoplay'] ? 1 : 0;
	$mute = $atts['mute'] ? 1 : 0;
	$loop = $atts['loop'] ? 1 : 0;
	$iframe = '<iframe width="'.$iframe_width.'" height="'.$iframe_height.'" src="https://www.youtube.com/embed/'.$youtube_id.'?autoplay='.$autoplay.'&mute='.$mute.'&controls='.$controls.'&loop='.$loop.'&rel=0&autohide=1&showinfo=0&playsinline=1&iv_load_policy=3&playlist='.$youtube_id.'" title="'.$title.'" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';


	// Output Code
	$output ='<div class="yt_frame '.$wrapper_class.'">';
	if($pointer):
		$output.='<div style="pointer-events:none;">';
	endif;
	$output .= $iframe;
	if($pointer):
		$output.='</div>';
	endif;
	$output.='</div>';

	return $output;
}
add_shortcode( 'youtube_iframe', 'create_youtubeiframe_shortcode' );
